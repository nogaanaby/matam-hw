#hw1
#Applied by:
Noga Anaby 318298296
Shahar Amshili 308054337
